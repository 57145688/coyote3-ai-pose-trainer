package com.sjzwolf.manual;

/** UI requests may change targets only during an explicitly started session. */
public final class ControlState {
    public boolean running=false,zeroConfirmed=false;
    public int a=0,b=0,capA=0,capB=0;
    public void stop(){running=false;zeroConfirmed=false;a=0;b=0;}
    public void confirmZero(){zeroConfirmed=true;}
    public void start(){if(!zeroConfirmed)throw new IllegalStateException("主机归零尚未确认");running=true;a=b=0;}
    public void caps(int x,int y){if(running)throw new IllegalStateException("请先停止");Protocol.range(x,0,200);Protocol.range(y,0,200);capA=x;capB=y;}
    public void step(boolean channelA,int delta){if(!running)throw new IllegalStateException("尚未手动开始");if(delta!=1&&delta!=-1)throw new IllegalArgumentException();if(channelA)a=Math.max(0,Math.min(capA,a+delta));else b=Math.max(0,Math.min(capB,b+delta));}
}
