package com.sjzwolf.manual;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

@SuppressWarnings("deprecation")
public class MainActivity extends Activity {
    final Handler h=new Handler(Looper.getMainLooper());
    final ControlState state=new ControlState();
    BluetoothAdapter adapter; BluetoothGatt gatt; BluetoothGattCharacteristic write;
    BluetoothLeScanner scanner; ScanCallback scanCallback;
    boolean ready=false,busy=false,stopPending=false,foreground=false,scanning=false,connecting=false;
    int seq=0,pending=0,expectedA=0,expectedB=0,tick=0,actualA=-1,actualB=-1;
    long pendingAt=0,writeAt=0,sessionAt=0,connectAt=0;
    int fa=10,fb=10,ampA=0,ampB=0,shape=0;
    LinearLayout root,body,devices; TextView status,values,logView; String logText="";
    EditText capAInput,capBInput,faInput,fbInput,ampAInput,ampBInput;
    Spinner shapeInput; Button start;
    static UUID uuid(String x){return UUID.fromString("0000"+x+"-0000-1000-8000-00805f9b34fb");}
    int dp(int n){return (int)(getResources().getDisplayMetrics().density*n);}
    public void onCreate(Bundle b){super.onCreate(b);adapter=((BluetoothManager)getSystemService(BLUETOOTH_SERVICE)).getAdapter();ui();h.post(loop);}
    TextView text(String t,int size){TextView v=new TextView(this);v.setText(t);v.setTextSize(size);v.setTextColor(Color.rgb(224,236,244));v.setPadding(0,dp(8),0,dp(8));return v;}
    void label(String t){body.addView(text(t,16));}
    Button button(String t,Runnable r){Button b=new Button(this);b.setText(t);b.setAllCaps(false);b.setMinHeight(dp(50));b.setOnClickListener(v->{try{r.run();}catch(Exception e){log(e.getMessage());}});return b;}
    EditText field(String title,int value){label(title);EditText e=new EditText(this);e.setSingleLine();e.setTextColor(Color.WHITE);e.setInputType(2);e.setText(""+value);body.addView(e);return e;}
    void ui(){
        root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(Color.rgb(8,20,31));root.setPadding(dp(16),dp(10),dp(16),dp(6));
        root.setOnApplyWindowInsetsListener((v,i)->{android.graphics.Insets s=i.getInsets(WindowInsets.Type.systemBars());v.setPadding(dp(16)+s.left,dp(10)+s.top,dp(16)+s.right,dp(6)+s.bottom);return i;});
        root.addView(text("手动控制  /  0.1 测试版",24));
        status=text("未连接 · 主机状态未知",15);root.addView(status);
        values=text("主机回报 A —   B —",22);root.addView(values);
        ScrollView scroll=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(1);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        label("独立 Android BLE · 所有强度变化由本人操作");
        body.addView(button("扫描郊狼三代",this::scan));devices=new LinearLayout(this);devices.setOrientation(1);body.addView(devices);
        body.addView(button("停止并断开连接",()->{BluetoothGatt old=gatt;stop("正在归零后断开");h.postDelayed(()->{if(gatt==old)close("已断开 · 主机状态未知");},1200);}));
        label("连接后先等待主机归零回执。上限和波形幅值初始为 0，需要本人设置。协议等级不是人体安全剂量。请先在不连接人体的情况下验收。");
        capAInput=field("A 本 APP 上限  0–200",0);capBInput=field("B 本 APP 上限  0–200",0);
        faInput=field("A 协议频率参数  10–1000（非 Hz）",10);fbInput=field("B 协议频率参数  10–1000（非 Hz）",10);
        ampAInput=field("A 波形幅值  0–100",0);ampBInput=field("B 波形幅值  0–100",0);
        shapeInput=new Spinner(this);shapeInput.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"恒定包络","间歇包络","渐变包络"}));body.addView(shapeInput);
        body.addView(button("应用设置（停止时）",this::configure));
        label("上限只限制本 APP 命令，不修改主机持久化设置。启动后每次手动 ±1。每次运行最多 30 秒，结束后重新确认。");
        start=button("手动开始 · 从零开始",this::confirmStart);body.addView(start);
        LinearLayout row=new LinearLayout(this);
        for(int n=0;n<4;n++){final int k=n;Button b=button(new String[]{"A −1","A +1","B −1","B +1"}[n],()->{state.step(k<2,k%2==0?-1:1);refresh();});row.addView(b,new LinearLayout.LayoutParams(0,dp(56),1));}body.addView(row);
        logView=text("",12);logView.setTypeface(Typeface.MONOSPACE);body.addView(logView);
        Button stop=button("STOP  停止并归零",()->stop("本人停止"));stop.setTextColor(Color.WHITE);stop.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(190,40,60)));root.addView(stop,new LinearLayout.LayoutParams(-1,dp(64)));
        setContentView(root);refresh();
    }
    void log(String s){if(s==null)s="未知错误";logText=s+"\n"+logText;if(logText.length()>2000)logText=logText.substring(0,2000);logView.setText(logText);}
    void refresh(){values.setText("主机回报 A "+(actualA<0?"—":actualA)+"   B "+(actualB<0?"—":actualB)+"\n请求 A "+state.a+"   B "+state.b);start.setEnabled(ready&&state.zeroConfirmed&&!state.running&&foreground);}
    int number(EditText e){return Integer.parseInt(e.getText().toString().trim());}
    void configure(){if(state.running)throw new IllegalStateException("请先 STOP");int x=number(capAInput),y=number(capBInput),f=number(faInput),g=number(fbInput),u=number(ampAInput),v=number(ampBInput);Protocol.range(x,0,200);Protocol.range(y,0,200);Protocol.frequency(f);Protocol.frequency(g);Protocol.range(u,0,100);Protocol.range(v,0,100);state.caps(x,y);fa=f;fb=g;ampA=u;ampB=v;shape=shapeInput.getSelectedItemPosition();log("设置已应用于本 APP；主机软上限未修改");}
    void confirmStart(){if(!ready||!foreground||!state.zeroConfirmed)return;new AlertDialog.Builder(this).setTitle("开始手动会话").setMessage("强度从 0 开始，仅由 ±1 按钮改变。30 秒后停止；离开 APP 即请求归零。断联时软件无法保证主机已停止，请使用主机实体控制。测试版尚未通过实机验收。").setNegativeButton("取消",null).setPositiveButton("本人开始",(d,w)->{if(!ready||!foreground||!state.zeroConfirmed)return;state.start();sessionAt=SystemClock.elapsedRealtime();tick=0;status.setText("手动运行 · 30 秒限时");refresh();}).show();}
    boolean permissions(){return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;}
    void scan(){
        if(gatt!=null||connecting){log("请先停止并断开现有连接");return;}
        if(!permissions()){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},1);return;}
        if(adapter==null||!adapter.isEnabled()){log("请在手机设置中开启蓝牙");return;}
        stopScan();devices.removeAllViews();scanner=adapter.getBluetoothLeScanner();Set<String> seen=new HashSet<>();
        scanCallback=new ScanCallback(){public void onScanResult(int t,ScanResult r){h.post(()->{if(!scanning||!foreground)return;BluetoothDevice d=r.getDevice();if(seen.add(d.getAddress()))devices.addView(button("连接 "+d.getAddress()+"  "+r.getRssi()+" dBm",()->connect(d)));});}public void onScanFailed(int c){h.post(()->{stopScan();log("扫描失败 "+c);});}};
        scanning=true;status.setText("扫描中 · 请先关闭旧控制网页的连接");scanner.startScan(Collections.singletonList(new ScanFilter.Builder().setDeviceName("47L121000").build()),new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(),scanCallback);
        h.postDelayed(()->{if(scanning){stopScan();log("扫描结束；点击列表中的主机连接");}},12000);
    }
    void stopScan(){if(scanning&&scanner!=null&&scanCallback!=null)try{scanner.stopScan(scanCallback);}catch(Exception ignored){}scanning=false;}
    public void onRequestPermissionsResult(int n,String[] p,int[] r){super.onRequestPermissionsResult(n,p,r);log(permissions()?"权限已授予，请再次点击扫描":"附近设备权限未授予");}
    void connect(BluetoothDevice d){if(gatt!=null||!foreground)return;stopScan();state.stop();connecting=true;connectAt=SystemClock.elapsedRealtime();status.setText("正在连接并验证服务");gatt=d.connectGatt(this,false,callback,BluetoothDevice.TRANSPORT_LE);}
    final BluetoothGattCallback callback=new BluetoothGattCallback(){
        public void onConnectionStateChange(BluetoothGatt g,int s,int n){h.post(()->{if(g!=gatt)return;if(s!=0||n==BluetoothProfile.STATE_DISCONNECTED){close("连接中断 · 主机状态未知");return;}if(n==BluetoothProfile.STATE_CONNECTED){if(!g.discoverServices())close("服务发现启动失败");}});}
        public void onServicesDiscovered(BluetoothGatt g,int s){h.post(()->{if(g!=gatt)return;try{if(s!=0)throw new Exception("服务发现失败");BluetoothGattService svc=g.getService(uuid("180c"));if(svc==null)throw new Exception("不是兼容的三代主机");write=svc.getCharacteristic(uuid("150a"));BluetoothGattCharacteristic notify=svc.getCharacteristic(uuid("150b"));if(write==null||notify==null)throw new Exception("控制特性缺失");if(!g.setCharacteristicNotification(notify,true))throw new Exception("订阅通知失败");BluetoothGattDescriptor desc=notify.getDescriptor(uuid("2902"));if(desc==null)throw new Exception("通知描述符缺失");desc.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);if(!g.writeDescriptor(desc))throw new Exception("订阅启动失败");}catch(Exception e){close(e.getMessage());}});}
        public void onDescriptorWrite(BluetoothGatt g,BluetoothGattDescriptor d,int s){h.post(()->{if(g!=gatt)return;if(s!=0){close("通知订阅失败");return;}connecting=false;ready=true;stop("已连接 · 等待主机归零回执");});}
        public void onCharacteristicWrite(BluetoothGatt g,BluetoothGattCharacteristic c,int s){h.post(()->{if(g!=gatt)return;busy=false;if(s!=0){close("写入失败 · 主机状态未知，请用主机停止");return;}if(stopPending)sendStop();});}
        public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){byte[] v=c.getValue();if(v!=null){byte[] data=v.clone();h.post(()->receive(g,data));}}
    };
    void receive(BluetoothGatt g,byte[] p){if(g!=gatt||p.length<4||(p[0]&255)!=0xb1)return;int a=p[2]&255,b=p[3]&255;if(a>200||b>200){stop("主机回报异常");return;}actualA=a;actualB=b;
        if(pending!=0&&(p[1]&255)==pending){boolean zero=expectedA==0&&expectedB==0&&a==0&&b==0;pending=0;if(!state.running&&zero&&!stopPending){state.confirmZero();status.setText("已连接 · 主机已回报归零");}}
        if(state.running&&(a>state.capA||b>state.capB))stop("回报超过本 APP 上限");
        if(!state.running&&(a!=0||b!=0))stop("停止状态检测到非零回报，重新请求归零");refresh();
    }
    void send(boolean output){if(!ready||write==null||busy||pending!=0)return;seq=seq%15+1;expectedA=output?state.a:0;expectedB=output?state.b:0;pending=seq;pendingAt=SystemClock.elapsedRealtime();byte[] p=Protocol.frame(seq,expectedA,expectedB,fa,fb,ampA,ampB,shape,tick++,output);busy=true;writeAt=pendingAt;try{write.setWriteType((write.getProperties()&BluetoothGattCharacteristic.PROPERTY_WRITE)!=0?BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT:BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);write.setValue(p);if(!gatt.writeCharacteristic(write))close("写入未启动 · 主机状态未知");}catch(Exception e){close("写入异常 · 请在主机停止");}}
    void stop(String why){state.stop();getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);pending=0;stopPending=ready;status.setText(why);log(why);sendStop();refresh();}
    void sendStop(){if(!stopPending||busy||!ready)return;stopPending=false;send(false);}
    void close(String why){stopScan();state.stop();ready=false;connecting=false;busy=false;pending=0;stopPending=false;actualA=actualB=-1;BluetoothGatt old=gatt;gatt=null;write=null;if(old!=null)try{old.disconnect();old.close();}catch(Exception ignored){}status.setText(why);log(why);refresh();}
    final Runnable loop=new Runnable(){public void run(){long now=SystemClock.elapsedRealtime();if(connecting&&now-connectAt>12000)close("连接验证超时");if(busy&&now-writeAt>1500)close("蓝牙写入超时 · 请用主机停止");if(pending!=0&&now-pendingAt>1500){if(state.running)stop("回执超时，停止并请求归零");else close("归零未确认 · 请用主机停止");}if(state.running){if(!foreground||now-sessionAt>=30000)stop("会话结束，等待归零回执");else{getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);send(true);}}h.postDelayed(this,100);}};
    protected void onResume(){super.onResume();foreground=true;if(start!=null)refresh();}
    protected void onPause(){foreground=false;stopScan();if(ready)stop("APP 离开前台，等待归零回执");else if(connecting)close("离开前台，连接已取消");super.onPause();}
    protected void onDestroy(){h.removeCallbacksAndMessages(null);close("APP 已关闭 · 请确认主机状态");super.onDestroy();}
}
