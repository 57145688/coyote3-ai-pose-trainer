package com.sjzwolf.manual;

/** Pure protocol encoder. No timers, Bluetooth calls or automatic intensity changes. */
public final class Protocol {
    private Protocol() {}
    static void range(int n,int lo,int hi){if(n<lo||n>hi)throw new IllegalArgumentException("参数越界");}
    public static int frequency(int n){range(n,10,1000);return n<=100?n:n<=600?100+(n-100)/5:200+(n-600)/10;}
    public static byte[] frame(int seq,int a,int b,int fa,int fb,int ampA,int ampB,int shape,int tick,boolean output){
        range(seq,1,15);range(a,0,200);range(b,0,200);range(ampA,0,100);range(ampB,0,100);range(shape,0,2);
        byte[] p=new byte[20];p[0]=(byte)0xb0;p[1]=(byte)((seq<<4)|15);
        p[2]=(byte)(output?a:0);p[3]=(byte)(output?b:0);
        for(int i=0;i<4;i++){
            int k=(tick*4+i)%40;double env=shape==0?1:shape==1?(k<20?1:0):(k<20?k/20.0:(40-k)/20.0);
            p[4+i]=(byte)frequency(fa);p[12+i]=(byte)frequency(fb);
            p[8+i]=(byte)(output?Math.round(ampA*env):0);p[16+i]=(byte)(output?Math.round(ampB*env):0);
        }
        return p;
    }
}
