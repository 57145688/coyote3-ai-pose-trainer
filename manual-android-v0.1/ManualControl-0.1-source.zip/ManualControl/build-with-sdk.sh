#!/usr/bin/env bash
set -euo pipefail
# Usage: ANDROID_SDK_ROOT=/path/to/sdk bash build-with-sdk.sh
cd "$(dirname "$0")"
: "${ANDROID_SDK_ROOT:?Set ANDROID_SDK_ROOT to an SDK with platform 35 and build-tools 35.0.0}"
bt="$ANDROID_SDK_ROOT/build-tools/35.0.0"
api="$ANDROID_SDK_ROOT/platforms/android-35/android.jar"
mkdir -p out/classes out/dex
javac --release 8 -d out/tests app/src/main/java/com/sjzwolf/manual/Protocol.java app/src/main/java/com/sjzwolf/manual/ControlState.java tests/CoreTest.java
java -cp out/tests com.sjzwolf.manual.CoreTest
javac -source 8 -target 8 -bootclasspath "$api:$bt/core-lambda-stubs.jar" -d out/classes app/src/main/java/com/sjzwolf/manual/*.java
jar cf out/classes.jar -C out/classes .
"$bt/d8" --lib "$api" --min-api 31 --output out/dex out/classes.jar
"$bt/aapt2" link -I "$api" --manifest app/src/main/AndroidManifest.xml -o out/unsigned.apk
(cd out/dex && zip -q ../unsigned.apk classes.dex)
"$bt/zipalign" -f 4 out/unsigned.apk out/aligned.apk
if [ ! -f out/debug.keystore ]; then
 keytool -genkeypair -keystore out/debug.keystore -storepass android -keypass android -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 3650 -dname 'CN=Android Debug,O=Development,C=US'
fi
"$bt/apksigner" sign --ks out/debug.keystore --ks-pass pass:android --key-pass pass:android --out out/ManualControl-0.1.apk out/aligned.apk
"$bt/apksigner" verify --verbose out/ManualControl-0.1.apk
