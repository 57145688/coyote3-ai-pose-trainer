package com.sjzwolf.manual;
public class CoreTest {
    static int count=0;
    static void check(boolean x){count++;if(!x)throw new AssertionError("case "+count);}
    static void rejects(Runnable r){try{r.run();throw new AssertionError("not rejected");}catch(IllegalArgumentException|IllegalStateException e){count++;}}
    public static void main(String[] a){
        ControlState s=new ControlState();rejects(s::start);rejects(()->s.step(true,1));s.caps(2,3);s.confirmZero();s.start();
        for(int i=0;i<10;i++){s.step(true,1);s.step(false,1);}check(s.a==2&&s.b==3);rejects(()->s.caps(4,4));
        s.stop();check(s.a==0&&s.b==0&&!s.running&&!s.zeroConfirmed);rejects(()->s.step(true,1));rejects(s::start);
        s.confirmZero();s.start();check(s.a==0&&s.b==0);for(int i=0;i<5;i++)s.step(true,-1);check(s.a==0);
        int[] inputs={10,100,101,600,601,1000},outputs={10,100,100,200,200,240};for(int i=0;i<inputs.length;i++)check(Protocol.frequency(inputs[i])==outputs[i]);
        rejects(()->Protocol.frequency(9));rejects(()->Protocol.frequency(1001));
        for(int seq=1;seq<=15;seq++)for(int shape=0;shape<3;shape++){
            byte[] p=Protocol.frame(seq,200,199,10,1000,100,99,shape,23,false);check(p.length==20&&(p[1]&255)==((seq<<4)|15));check(p[2]==0&&p[3]==0);
            for(int i=0;i<4;i++){check(p[4+i]==10&&(p[12+i]&255)==240);check(p[8+i]==0&&p[16+i]==0);}
            p=Protocol.frame(seq,200,199,10,1000,100,99,shape,23,true);check((p[2]&255)==200&&(p[3]&255)==199);for(int i=0;i<4;i++)check((p[8+i]&255)<=100&&(p[16+i]&255)<=99);
        }
        rejects(()->Protocol.frame(0,0,0,10,10,0,0,0,0,false));rejects(()->Protocol.frame(1,201,0,10,10,0,0,0,0,true));
        System.out.println("PASS: "+count+" protocol/state assertions; no hardware tested");
    }
}
